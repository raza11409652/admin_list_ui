export interface Admin {
  id: string;
  name: string;
  email: string;
  role: string;
}
