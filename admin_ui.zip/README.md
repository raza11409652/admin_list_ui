# To run application in local follow following steps
   -  Extract or clone app in your local system
   - Run npm i
   - Run npm dev
   - Make sure you have installed node js >=16.0 